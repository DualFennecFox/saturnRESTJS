INSERT INTO trips 
(depsite, arrsite, departure, arrival, price, bus, img, seats, depdate) 
VALUES 
('cc', 'cac', '08:00 PM', '10:00 PM', 30.00, 'was', 'aeroexp', 5, '2024-10-30');